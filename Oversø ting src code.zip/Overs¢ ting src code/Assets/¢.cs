﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ø : MonoBehaviour
{

    public static Vector3 pos = new Vector3(0,0,0);
    // Start is called before the first frame update
    public ø(Vector3 posin){
        print(posin);
        pos = posin;
        print(pos);
        //transform.position = pos;
    }
}
