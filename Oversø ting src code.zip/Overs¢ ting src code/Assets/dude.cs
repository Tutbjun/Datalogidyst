﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dude : MonoBehaviour
{
    
    static public GameObject[] øer;
    public GameObject planke;
    stiCalc jørgen;
    static float[] øPos;
    bool stiFundet = false;
    float moveTimeDynamic;
    float moveTime = 500;
    int moveIndex = 0;
    // Start is called before the first frame update
    void Start()
    {
        Vector3 pos = new Vector3(CreateObjects.LPublic/2,0,-0.5f);
        transform.position = pos;
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Time.frameCount < 2){
            jørgen = new stiCalc();
            jørgen.plankePrivate = planke;
            print("jørgen er skabt");
        }
        øer = GameObject.FindGameObjectsWithTag ("ø");
        
        if(jørgen.path.Count < øer.Length){
            øPos = new float[øer.Length];
            for(int i = 0; i < øer.Length; i++){
                øPos[i] = øer[i].transform.position.y;
            }
            jørgen.tjekSti();
            jørgen.knækSti();
            /*foreach(var e in jørgen.pathLengths){
                print(e);
            }*/

            stiFundet = true;
            for(int i = 0; i < jørgen.pathLengths.Count; i++){
                if(!jørgen.pathLengths[i]){
                    stiFundet = false;
                }
            }
            if(stiFundet){
                moveTimeDynamic -= Time.deltaTime*1000;
                if(moveTimeDynamic < 0){
                    moveTimeDynamic += moveTime;
                    moveIndex++;
                    if(moveIndex < jørgen.path.Count){
                        transform.position += jørgen.path[jørgen.path.Count - (moveIndex + 1)] - jørgen.path[jørgen.path.Count - moveIndex];
                    }
                }
            }
        }
        else{
            print("Sti ikke fundet");
        }
    }

    public class stiCalc{
        public List<Vector3> path;
        public List<bool> pathLengths;
        public GameObject plankePrivate;
        

        public stiCalc(){
            pathLengths = new List<bool>();
            path = new List<Vector3>();
            Vector3 startPos = new Vector3(CreateObjects.LPublic/2,CreateObjects.WPublic,-0.5f);
            Vector3 slutPos = new Vector3(CreateObjects.LPublic/2,0,-0.5f);
            path.Add(startPos);
            path.Add(slutPos);
        }
        public void knækSti(){
            int iMax = pathLengths.Count;
            for (int i = 0; i < pathLengths.Count; i++){
                if(pathLengths[i]){
                    Vector3 midPoint = (path[i+1] + path[i]) / 2;

                    Vector3 plankeRetning = path[i+1] - path[i];
                    plankeRetning = plankeRetning.normalized;
                    float angle = Mathf.Acos( Vector3.Dot(plankeRetning,new Vector3(0,-1,0))/plankeRetning.magnitude );
                    if(plankeRetning.x > 0) angle *= -1;
                    Instantiate(plankePrivate, midPoint, new Quaternion(angle,Mathf.PI/2,0,0));
                }
            }
            for(int i = 0; i < iMax; i++){
                if(!pathLengths[i]){
                    Vector3 midPoint = (path[i+1] + path[i]) / 2;

                    /*Vector3 plankeRetning = path[i+1] - path[i];
                    plankeRetning = plankeRetning.normalized;
                    float angle = Mathf.Acos( Vector3.Dot(plankeRetning,new Vector3(0,-1,0))/plankeRetning.magnitude );
                    print(angle);
                    print(plankeRetning);
                    Instantiate(plankePrivate, midPoint, new Quaternion(angle,Mathf.PI,0,0));*/


                    float[] øDistance = new float[dude.øer.Length];
                    for ( int i2 = 0; i2 < dude.øer.Length; i2++){
                        Vector3 deltaVector = dude.øer[i2].transform.position - midPoint;
                        øDistance[i2] = deltaVector.magnitude;
                    }
                    float shortest = 0;
                    int shortestIndex = 0;
                    for ( int i2 = 0; i2 < dude.øer.Length; i2++){
                        if(i2 == 0) shortest = øDistance[i2];
                        else if(øDistance[i2] < shortest){
                            bool indexInPath = false;
                            
                            for(int i3 = 0; i3 < path.Count; i3++){
                                if(path[i3] == dude.øer[i2].transform.position){
                                    indexInPath = true;
                                }
                            }

                            if(!indexInPath){
                                shortest = øDistance[i2];
                                shortestIndex = i2;
                            }
                        }
                    }
                    path.Insert(i+1, dude.øer[shortestIndex].transform.position);
                    print("Tilføjet " + dude.øer[shortestIndex].transform.position + " i path");

                    i++;
                    iMax++;
                    pathLengths.Insert(i, false);
                }
            }
            //lav et knæk
                //find midtpunkt
                //tjek potentielt nye punkter ud fra midpunktet ved at tjekke med større og større radius (punkter i listen er exkluderet)
                //dan nyt punkt i listen (i den rigtige plads)
            }
        public void tjekSti(){
            pathLengths.Clear();
            for(int i = 0; i < path.Count-1; i++){
                Vector3 deltaPoint = path[i+1] - path[i];
                pathLengths.Add(true);
                if(i == 0 || i == path.Count - 1){
                    if(Mathf.Abs(deltaPoint.y) > CreateObjects.plankeLængdePublic){
                        pathLengths[i] = false;
                    }
                }
                else if(i > 0){
                    if(deltaPoint.magnitude > CreateObjects.plankeLængdePublic){
                        pathLengths[i] = false;
                    }
                }
            }
            
            //tjek længder
                //phytagoras
            }
        }
    }
    
