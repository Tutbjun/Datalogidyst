﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateObjects : MonoBehaviour
{
    public float n;
    public float W;
    public float L;
    public float plankeLængde;
    public static float plankeLængdePublic;
    public static float nPublic;
    public static float WPublic;
    public static float LPublic;
    List<Vector3> øPos = new List<Vector3>();
    public GameObject øObjekt;

    // Start is called before the first frame update
    void Start()
    {
        for(int i = 0; i < n; i++){
            float x = Random.Range(0,L);
            float y = Random.Range(0,W);
            øPos.Add(new Vector3(x,y,-0.5f));
        }
        print("ja");
        foreach(var e in øPos){
            ø.Instantiate (øObjekt, e, new Quaternion() );

        }
        assignPublicVariables();
    }

    // Update is called once per frame
    void Update()
    {
        assignPublicVariables();
        
        
    }
    void assignPublicVariables(){
        nPublic = n;
        WPublic = W;
        LPublic = L;
        plankeLængdePublic = plankeLængde;
    }
}
