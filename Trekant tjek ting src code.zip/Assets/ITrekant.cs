﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ITrekant : MonoBehaviour
{
    public Object me;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(!ObjectMaster.iTrekant){
            Destroy(me,0);
            print("destroyed");
        }
    }
}
