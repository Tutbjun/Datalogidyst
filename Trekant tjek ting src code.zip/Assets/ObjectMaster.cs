﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMaster : MonoBehaviour
{
    public Vector2[] pointRange = new Vector2[2];
    public GameObject punktObjekt;
    public static Vector3 camPos;
    public static Vector2[] pointPos = new Vector2[3];
    public Object iTrekantMarker;
    public GameObject iTrekantMarkerAlso;
    public static bool iTrekant;
    // Start is called before the first frame update
    void Start()
    {

        for(int i = 0; i < 3; i++){
            Vector2 pointPos2D = new Vector2();
            pointPos2D.x = Random.Range(pointRange[0].x,pointRange[1].x);
            pointPos2D.y = Random.Range(pointRange[0].y,pointRange[1].y);
            pointPos[i] = pointPos2D;
            Instantiate(punktObjekt, pointPos[i], new Quaternion());
        }
        camPos.x = (pointRange[0].x + pointRange[1].x) / 2;
        camPos.y = (pointRange[0].y + pointRange[1].y) / 2;
        Vector2 deltaPointRange;
        deltaPointRange = pointRange[1] - pointRange[0];
        camPos.z = -deltaPointRange.magnitude;
        
    }

    // Update is called once per frame
    void Update()
    {
        iTrekant = true;
        for(int i = 0; i < 3; i++){
            Vector2[] deltaPoint = new Vector2[3]; //nummer 0 er til punktet
            for(int i2 = 1; i2 < 3; i2++){
                int i3 = i + i2;
                if(i3 > 2){
                    i3 -= 3;
                }
                deltaPoint[i2] = pointPos[i3] - pointPos[i];
            }
            deltaPoint[0] = pointer.pos - pointPos[i];
            float angleStatic;
            angleStatic = Mathf.Acos( Vector2.Dot(deltaPoint[1],deltaPoint[2]) / (deltaPoint[1].magnitude * deltaPoint[2].magnitude) );
            float angleDynamic;
            angleDynamic = Mathf.Acos( Vector2.Dot( deltaPoint[1] , deltaPoint[0] ) / ( deltaPoint[1].magnitude * deltaPoint[0].magnitude ) );
            if(Mathf.Abs( angleDynamic ) > Mathf.Abs( angleStatic )){
                iTrekant = false;
            }
        }
        if(iTrekant){
            print("pointer i trekant");
            Instantiate(iTrekantMarkerAlso);
        }
        else if(!iTrekant){
            print("pointer ikke i trekant");
            Object.Destroy(iTrekantMarker,0);
        }

        Destroy(iTrekantMarker,0);
        
    }
}
